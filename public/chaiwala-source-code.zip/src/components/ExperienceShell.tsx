import React from 'react';

interface ExperienceShellProps {
  children?: React.ReactNode;
}

export const ExperienceShell: React.FC<ExperienceShellProps> = ({ children }) => {
  return (
    <div className="fixed inset-0 overflow-hidden select-none bg-[#0b0705]">
      {/* Authentic Chai Tapri Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-all duration-1000 ease-out"
        style={{
          backgroundImage: 'url("./background/chaiwala.jpg")',
          transform: 'scale(1.02)',
        }}
      />

      {/* Warm Golden Hour Sunset Atmosphere */}
      <div
        className="absolute rounded-full pointer-events-none"
        style={{
          width: 'min(50vw, 600px)',
          height: 'min(50vw, 600px)',
          bottom: '22%',
          left: '32%',
          background: 'radial-gradient(circle, rgba(232, 147, 74, 0.45) 0%, rgba(217, 98, 47, 0.2) 40%, rgba(0,0,0,0) 70%)',
          filter: 'blur(50px)',
        }}
      />

      {/* Atmospheric Vignette & Contrast Overlays */}
      <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-[#0b0705]/95 via-transparent to-[#0b0705]/60 z-[2]" />
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_center,_transparent_45%,_rgba(11,7,5,0.75)_100%)] z-[2]" />

      {/* Shell Inner Container for UI */}
      <div className="relative z-10 w-full h-full flex flex-col justify-between">
        {children}
      </div>
    </div>
  );
};
