// Authentic Chai Wala Ambient Sound Engine
// Web Audio API procedural synthesizers for Chai Simmer, Monsoon Rain, Hearth Fire, Night Crickets, Alpha Waves & Chai Pour

export interface ChaiAmbientMixer {
  simmer: number;
  rain: number;
  fire: number;
  crickets: number;
  alpha: number;
  whistle: number;
  master: number;
}

export const DEFAULT_CHAI_MIXER: ChaiAmbientMixer = {
  simmer: 0.6,
  rain: 0.4,
  fire: 0.2,
  crickets: 0.15,
  alpha: 0.25,
  whistle: 0.0,
  master: 0.75,
};

class AudioEngineController {
  private ctx: AudioContext | null = null;
  private isAmbientRunning = false;

  private masterGain: GainNode | null = null;
  private simmerGain: GainNode | null = null;
  private rainGain: GainNode | null = null;
  private fireGain: GainNode | null = null;
  private cricketsGain: GainNode | null = null;
  private alphaGain: GainNode | null = null;
  private whistleGain: GainNode | null = null;

  private activeNodes: { stop: () => void }[] = [];
  private currentMixer: ChaiAmbientMixer = { ...DEFAULT_CHAI_MIXER };

  private initContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  // Signature Traditional Hot Cutting Chai Pour Sound (with authentic cutting glass clink)
  public playChaiPour(onComplete?: () => void) {
    try {
      const ctx = this.initContext();
      const now = ctx.currentTime;
      const duration = 2.4;

      const bufferSize = ctx.sampleRate * duration;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = buffer.getChannelData(0);
      let lastOut = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        output[i] = (lastOut + 0.02 * white) / 1.02;
        lastOut = output[i];
        output[i] *= 3.5;
      }
      const streamSource = ctx.createBufferSource();
      streamSource.buffer = buffer;

      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(650, now);
      filter.frequency.exponentialRampToValueAtTime(1050, now + duration * 0.7);
      filter.frequency.exponentialRampToValueAtTime(820, now + duration);
      filter.Q.setValueAtTime(4, now);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.42, now + 0.15);
      gain.gain.setValueAtTime(0.38, now + duration - 0.4);
      gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

      streamSource.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      streamSource.start(now);
      streamSource.stop(now + duration);

      // Authentic Cutting Glass clink sound
      const clinkOsc = ctx.createOscillator();
      const clinkGain = ctx.createGain();
      clinkOsc.type = 'sine';
      clinkOsc.frequency.setValueAtTime(2450, now + duration - 0.2);
      clinkGain.gain.setValueAtTime(0.15, now + duration - 0.2);
      clinkGain.gain.exponentialRampToValueAtTime(0.001, now + duration);
      clinkOsc.connect(clinkGain);
      clinkGain.connect(ctx.destination);
      clinkOsc.start(now + duration - 0.2);
      clinkOsc.stop(now + duration);

      setTimeout(() => onComplete?.(), duration * 1000);
    } catch {
      onComplete?.();
    }
  }

  // Mindfulness Tibetan Singing Bell chime
  public playSingingBell() {
    try {
      const ctx = this.initContext();
      const now = ctx.currentTime;
      [440, 880, 1320, 1760].forEach((f, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(f, now);
        gain.gain.setValueAtTime([0.35, 0.15, 0.08, 0.03][idx], now);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 3.5);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 3.6);
      });
    } catch {}
  }

  // Start continuous ambient soundscape
  public startAmbientSoundscape() {
    if (this.isAmbientRunning) return;
    try {
      const ctx = this.initContext();
      this.isAmbientRunning = true;

      this.masterGain = ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.currentMixer.master, ctx.currentTime);
      this.masterGain.connect(ctx.destination);

      // 1. Spiced Chai Simmer & Boil
      this.setupSimmerTrack(ctx);

      // 2. Monsoon Window Rain
      this.setupRainTrack(ctx);

      // 3. Hearth Fire & Coal Stove
      this.setupFireTrack(ctx);

      // 4. Night Crickets
      this.setupCricketsTrack(ctx);

      // 5. 432Hz Binaural Alpha Waves
      this.setupAlphaTrack(ctx);
    } catch {}
  }

  private setupSimmerTrack(ctx: AudioContext) {
    this.simmerGain = ctx.createGain();
    this.simmerGain.gain.setValueAtTime(this.currentMixer.simmer * 0.38, ctx.currentTime);
    this.simmerGain.connect(this.masterGain!);

    const bufferSize = ctx.sampleRate * 2.5;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * 0.24;
    }
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.loop = true;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(480, ctx.currentTime);

    source.connect(filter);
    filter.connect(this.simmerGain);
    source.start();

    this.activeNodes.push({
      stop: () => {
        try {
          source.stop();
        } catch {}
      },
    });
  }

  private setupRainTrack(ctx: AudioContext) {
    this.rainGain = ctx.createGain();
    this.rainGain.gain.setValueAtTime(this.currentMixer.rain * 0.35, ctx.currentTime);
    this.rainGain.connect(this.masterGain!);

    const bufferSize = ctx.sampleRate * 2.5;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let b0 = 0,
      b1 = 0,
      b2 = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.969 * b2 + white * 0.153852;
      data[i] = (b0 + b1 + b2) * 0.28;
    }
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.loop = true;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(950, ctx.currentTime);

    source.connect(filter);
    filter.connect(this.rainGain);
    source.start();

    this.activeNodes.push({
      stop: () => {
        try {
          source.stop();
        } catch {}
      },
    });
  }

  private setupFireTrack(ctx: AudioContext) {
    this.fireGain = ctx.createGain();
    this.fireGain.gain.setValueAtTime(this.currentMixer.fire * 0.25, ctx.currentTime);
    this.fireGain.connect(this.masterGain!);

    const bufferSize = ctx.sampleRate * 2;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() < 0.008 ? (Math.random() * 2 - 1) * 0.75 : 0;
    }
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.loop = true;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(750, ctx.currentTime);

    source.connect(filter);
    filter.connect(this.fireGain);
    source.start();

    this.activeNodes.push({
      stop: () => {
        try {
          source.stop();
        } catch {}
      },
    });
  }

  private setupCricketsTrack(ctx: AudioContext) {
    this.cricketsGain = ctx.createGain();
    this.cricketsGain.gain.setValueAtTime(this.currentMixer.crickets * 0.15, ctx.currentTime);
    this.cricketsGain.connect(this.masterGain!);

    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(4200, ctx.currentTime);

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(4200, ctx.currentTime);
    filter.Q.setValueAtTime(8, ctx.currentTime);

    osc.connect(filter);
    filter.connect(this.cricketsGain);
    osc.start();

    this.activeNodes.push({
      stop: () => {
        try {
          osc.stop();
        } catch {}
      },
    });
  }

  private setupAlphaTrack(ctx: AudioContext) {
    this.alphaGain = ctx.createGain();
    this.alphaGain.gain.setValueAtTime(this.currentMixer.alpha * 0.18, ctx.currentTime);
    this.alphaGain.connect(this.masterGain!);

    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    osc1.type = 'sine';
    osc2.type = 'sine';
    osc1.frequency.setValueAtTime(432, ctx.currentTime);
    osc2.frequency.setValueAtTime(442, ctx.currentTime); // 10Hz Alpha difference

    osc1.connect(this.alphaGain);
    osc2.connect(this.alphaGain);
    osc1.start();
    osc2.start();

    this.activeNodes.push({
      stop: () => {
        try {
          osc1.stop();
          osc2.stop();
        } catch {}
      },
    });
  }

  public stopAmbientSoundscape() {
    this.isAmbientRunning = false;
    this.activeNodes.forEach((n) => n.stop());
    this.activeNodes = [];
  }

  public setMixerLevels(newLevels: Partial<ChaiAmbientMixer>) {
    this.currentMixer = { ...this.currentMixer, ...newLevels };
    if (!this.ctx) return;
    const now = this.ctx.currentTime;

    if (this.masterGain && newLevels.master !== undefined) {
      this.masterGain.gain.linearRampToValueAtTime(newLevels.master, now + 0.1);
    }
    if (this.simmerGain && newLevels.simmer !== undefined) {
      this.simmerGain.gain.linearRampToValueAtTime(newLevels.simmer * 0.38, now + 0.1);
    }
    if (this.rainGain && newLevels.rain !== undefined) {
      this.rainGain.gain.linearRampToValueAtTime(newLevels.rain * 0.35, now + 0.1);
    }
    if (this.fireGain && newLevels.fire !== undefined) {
      this.fireGain.gain.linearRampToValueAtTime(newLevels.fire * 0.25, now + 0.1);
    }
    if (this.cricketsGain && newLevels.crickets !== undefined) {
      this.cricketsGain.gain.linearRampToValueAtTime(newLevels.crickets * 0.15, now + 0.1);
    }
    if (this.alphaGain && newLevels.alpha !== undefined) {
      this.alphaGain.gain.linearRampToValueAtTime(newLevels.alpha * 0.18, now + 0.1);
    }
  }

  public getMixerState(): ChaiAmbientMixer {
    return { ...this.currentMixer };
  }

  public isAmbientActive(): boolean {
    return this.isAmbientRunning;
  }
}

export const audioEngine = new AudioEngineController();
